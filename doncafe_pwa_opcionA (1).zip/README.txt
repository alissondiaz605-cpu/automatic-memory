Instrucciones - Don Café PWA

1) Subir todos los archivos a un hosting (Netlify, GitHub Pages o tu servidor).
2) Abrir la URL en el celular y usar 'Agregar a pantalla de inicio' para instalar.
3) Seleccionar rol: 'Propietario' para ver resumen y exportar; 'Empleado' oculta esas opciones.
4) Ingresar nombre del empleado para registrar quién hizo el reporte.
5) Exportar CSV e importar en Google Sheets.

Si quieres que te prepare la versión ya alojada en GitHub Pages o con Google Sheets integración (Apps Script), dímelo y lo configuro.